# PROJECT_R-Pima_Diabetes

## Description

Ce projet analyse des données santés de patients pour prédire s'ils sont diabatiques ou non à l'aide d'un modèle d'IA.

### Installation

``` r
install.packages(c("dplyr", "ggplot2", "tidyr"))
```

Cloner le projet : (dans le terminal de RStudio)

``` r
git clone https://github.com/(Ton_nom_sur_Github)/PROJECT_R-Pima_Diabetes.git
```

Charger les packages : (dans la console de RStudio)

``` r
library(dplyr)
library(ggplot2)
```

Exécuter le script principal main.R pour générer les résultats. Les contributions sont les bienvenues !\
1. Fork le dépôt 2. Créer une branche 3. Faire des modifications 4. Ouvrir une Pull Request

### Synchronisation avec GitHub (dans terminal de RStudio)

Récupérer les modifications depuis GitHub (pull) :

``` r
git pull origin main
```

Ajouter vos changements locaux :

``` r
git add .
```

Enregistrer vos modifications (commit) :

``` r
git commit -m "Message décrivant les changements"
```

Envoyer vos modifications sur GitHub (push) :

``` r
git push origin main
```
